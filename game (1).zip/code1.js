gdjs.Main_32menuCode = {};
gdjs.Main_32menuCode.localVariables = [];
gdjs.Main_32menuCode.idToCallbackMap = new Map();
gdjs.Main_32menuCode.GDNewTextObjects1= [];
gdjs.Main_32menuCode.GDNewTextObjects2= [];
gdjs.Main_32menuCode.GDYellowJellyButtonObjects1= [];
gdjs.Main_32menuCode.GDYellowJellyButtonObjects2= [];
gdjs.Main_32menuCode.GDYellowJellyButton2Objects1= [];
gdjs.Main_32menuCode.GDYellowJellyButton2Objects2= [];
gdjs.Main_32menuCode.GDYellowJellyButton3Objects1= [];
gdjs.Main_32menuCode.GDYellowJellyButton3Objects2= [];
gdjs.Main_32menuCode.GDNewText2Objects1= [];
gdjs.Main_32menuCode.GDNewText2Objects2= [];
gdjs.Main_32menuCode.GDbestscoreg_9595Objects1= [];
gdjs.Main_32menuCode.GDbestscoreg_9595Objects2= [];
gdjs.Main_32menuCode.GDcoinsgObjects1= [];
gdjs.Main_32menuCode.GDcoinsgObjects2= [];
gdjs.Main_32menuCode.GDCave_9595BackgroundObjects1= [];
gdjs.Main_32menuCode.GDCave_9595BackgroundObjects2= [];
gdjs.Main_32menuCode.GDNewSpriteObjects1= [];
gdjs.Main_32menuCode.GDNewSpriteObjects2= [];


gdjs.Main_32menuCode.asyncCallback15761452 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Main_32menuCode.localVariables);
gdjs.Main_32menuCode.localVariables.length = 0;
}
gdjs.Main_32menuCode.idToCallbackMap.set(15761452, gdjs.Main_32menuCode.asyncCallback15761452);
gdjs.Main_32menuCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Main_32menuCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__CrazyGamesAdApi__LoadSDK.func(runtimeScene, null), (runtimeScene) => (gdjs.Main_32menuCode.asyncCallback15761452(runtimeScene, asyncObjectsList)), 15761452, asyncObjectsList);
}
}

}


};gdjs.Main_32menuCode.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("YellowJellyButton3"), gdjs.Main_32menuCode.GDYellowJellyButton3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32menuCode.GDYellowJellyButton3Objects1.length;i<l;++i) {
    if ( gdjs.Main_32menuCode.GDYellowJellyButton3Objects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32menuCode.GDYellowJellyButton3Objects1[k] = gdjs.Main_32menuCode.GDYellowJellyButton3Objects1[i];
        ++k;
    }
}
gdjs.Main_32menuCode.GDYellowJellyButton3Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15757540);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Click_03.aac", 2, false, 100, 1);
}
{gdjs.evtTools.leaderboards.displayLeaderboard(runtimeScene, "cfaa8b1f-be50-4f18-a0f8-8a6c22a209ea", true);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("YellowJellyButton2"), gdjs.Main_32menuCode.GDYellowJellyButton2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32menuCode.GDYellowJellyButton2Objects1.length;i<l;++i) {
    if ( gdjs.Main_32menuCode.GDYellowJellyButton2Objects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32menuCode.GDYellowJellyButton2Objects1[k] = gdjs.Main_32menuCode.GDYellowJellyButton2Objects1[i];
        ++k;
    }
}
gdjs.Main_32menuCode.GDYellowJellyButton2Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Shop", false);
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Click_03.aac", 2, false, 100, 1);
}
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 6);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 1);
}
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 2);
}
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 3);
}
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 4);
}
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 5);
}
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 6);
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Pina Colada.aac", 6, false, 100, 1);
}

{ //Subevents
gdjs.Main_32menuCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() > 9999);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(9999);
}
{gdjs.evtTools.storage.writeNumberInJSONFile("local", "game", runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber());
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("YellowJellyButton"), gdjs.Main_32menuCode.GDYellowJellyButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32menuCode.GDYellowJellyButtonObjects1.length;i<l;++i) {
    if ( gdjs.Main_32menuCode.GDYellowJellyButtonObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32menuCode.GDYellowJellyButtonObjects1[k] = gdjs.Main_32menuCode.GDYellowJellyButtonObjects1[i];
        ++k;
    }
}
gdjs.Main_32menuCode.GDYellowJellyButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene", false);
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Click_03.aac", 2, false, 100, 1);
}
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 6);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("bestscoreg_"), gdjs.Main_32menuCode.GDbestscoreg_9595Objects1);
gdjs.copyArray(runtimeScene.getObjects("coinsg"), gdjs.Main_32menuCode.GDcoinsgObjects1);
{gdjs.evtTools.storage.readNumberFromJSONFile("local", "bestscore", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(1));
}
{gdjs.evtTools.storage.readNumberFromJSONFile("local", "game", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(0));
}
{for(var i = 0, len = gdjs.Main_32menuCode.GDbestscoreg_9595Objects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDbestscoreg_9595Objects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(1).getAsString());
}
}
{for(var i = 0, len = gdjs.Main_32menuCode.GDcoinsgObjects1.length ;i < len;++i) {
    gdjs.Main_32menuCode.GDcoinsgObjects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(0).getAsString());
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};

gdjs.Main_32menuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Main_32menuCode.GDNewTextObjects1.length = 0;
gdjs.Main_32menuCode.GDNewTextObjects2.length = 0;
gdjs.Main_32menuCode.GDYellowJellyButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDYellowJellyButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDYellowJellyButton2Objects1.length = 0;
gdjs.Main_32menuCode.GDYellowJellyButton2Objects2.length = 0;
gdjs.Main_32menuCode.GDYellowJellyButton3Objects1.length = 0;
gdjs.Main_32menuCode.GDYellowJellyButton3Objects2.length = 0;
gdjs.Main_32menuCode.GDNewText2Objects1.length = 0;
gdjs.Main_32menuCode.GDNewText2Objects2.length = 0;
gdjs.Main_32menuCode.GDbestscoreg_9595Objects1.length = 0;
gdjs.Main_32menuCode.GDbestscoreg_9595Objects2.length = 0;
gdjs.Main_32menuCode.GDcoinsgObjects1.length = 0;
gdjs.Main_32menuCode.GDcoinsgObjects2.length = 0;
gdjs.Main_32menuCode.GDCave_9595BackgroundObjects1.length = 0;
gdjs.Main_32menuCode.GDCave_9595BackgroundObjects2.length = 0;
gdjs.Main_32menuCode.GDNewSpriteObjects1.length = 0;
gdjs.Main_32menuCode.GDNewSpriteObjects2.length = 0;

gdjs.Main_32menuCode.eventsList1(runtimeScene);
gdjs.Main_32menuCode.GDNewTextObjects1.length = 0;
gdjs.Main_32menuCode.GDNewTextObjects2.length = 0;
gdjs.Main_32menuCode.GDYellowJellyButtonObjects1.length = 0;
gdjs.Main_32menuCode.GDYellowJellyButtonObjects2.length = 0;
gdjs.Main_32menuCode.GDYellowJellyButton2Objects1.length = 0;
gdjs.Main_32menuCode.GDYellowJellyButton2Objects2.length = 0;
gdjs.Main_32menuCode.GDYellowJellyButton3Objects1.length = 0;
gdjs.Main_32menuCode.GDYellowJellyButton3Objects2.length = 0;
gdjs.Main_32menuCode.GDNewText2Objects1.length = 0;
gdjs.Main_32menuCode.GDNewText2Objects2.length = 0;
gdjs.Main_32menuCode.GDbestscoreg_9595Objects1.length = 0;
gdjs.Main_32menuCode.GDbestscoreg_9595Objects2.length = 0;
gdjs.Main_32menuCode.GDcoinsgObjects1.length = 0;
gdjs.Main_32menuCode.GDcoinsgObjects2.length = 0;
gdjs.Main_32menuCode.GDCave_9595BackgroundObjects1.length = 0;
gdjs.Main_32menuCode.GDCave_9595BackgroundObjects2.length = 0;
gdjs.Main_32menuCode.GDNewSpriteObjects1.length = 0;
gdjs.Main_32menuCode.GDNewSpriteObjects2.length = 0;


return;

}

gdjs['Main_32menuCode'] = gdjs.Main_32menuCode;
