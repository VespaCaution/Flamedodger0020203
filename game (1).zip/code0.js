gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.localVariables = [];
gdjs.Untitled_32sceneCode.idToCallbackMap = new Map();
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDCave_9595BackgroundObjects1= [];
gdjs.Untitled_32sceneCode.GDCave_9595BackgroundObjects2= [];
gdjs.Untitled_32sceneCode.GDStoneObjects1= [];
gdjs.Untitled_32sceneCode.GDStoneObjects2= [];
gdjs.Untitled_32sceneCode.GDFireballObjects1= [];
gdjs.Untitled_32sceneCode.GDFireballObjects2= [];
gdjs.Untitled_32sceneCode.GDCannonObjects1= [];
gdjs.Untitled_32sceneCode.GDCannonObjects2= [];
gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595RectangleObjects1= [];
gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595RectangleObjects2= [];
gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1= [];
gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects2= [];
gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDNewTextObjects1= [];
gdjs.Untitled_32sceneCode.GDNewTextObjects2= [];
gdjs.Untitled_32sceneCode.GDBlueButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDBlueButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDNewText2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewText2Objects2= [];
gdjs.Untitled_32sceneCode.GDNewText3Objects1= [];
gdjs.Untitled_32sceneCode.GDNewText3Objects2= [];
gdjs.Untitled_32sceneCode.GDGold_9595CoinObjects1= [];
gdjs.Untitled_32sceneCode.GDGold_9595CoinObjects2= [];
gdjs.Untitled_32sceneCode.GDNewText4Objects1= [];
gdjs.Untitled_32sceneCode.GDNewText4Objects2= [];
gdjs.Untitled_32sceneCode.GDDino_9595VitaObjects1= [];
gdjs.Untitled_32sceneCode.GDDino_9595VitaObjects2= [];
gdjs.Untitled_32sceneCode.GDSkeletonObjects1= [];
gdjs.Untitled_32sceneCode.GDSkeletonObjects2= [];
gdjs.Untitled_32sceneCode.GDChickenObjects1= [];
gdjs.Untitled_32sceneCode.GDChickenObjects2= [];
gdjs.Untitled_32sceneCode.GDTommyObjects1= [];
gdjs.Untitled_32sceneCode.GDTommyObjects2= [];
gdjs.Untitled_32sceneCode.GDCat_95951Objects1= [];
gdjs.Untitled_32sceneCode.GDCat_95951Objects2= [];
gdjs.Untitled_32sceneCode.GDbeeObjects1= [];
gdjs.Untitled_32sceneCode.GDbeeObjects2= [];
gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595Rectangle2Objects1= [];
gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595Rectangle2Objects2= [];
gdjs.Untitled_32sceneCode.GDScore2Objects1= [];
gdjs.Untitled_32sceneCode.GDScore2Objects2= [];
gdjs.Untitled_32sceneCode.GDScore3Objects1= [];
gdjs.Untitled_32sceneCode.GDScore3Objects2= [];
gdjs.Untitled_32sceneCode.GDNewText5Objects1= [];
gdjs.Untitled_32sceneCode.GDNewText5Objects2= [];
gdjs.Untitled_32sceneCode.GDNewText6Objects1= [];
gdjs.Untitled_32sceneCode.GDNewText6Objects2= [];
gdjs.Untitled_32sceneCode.GDNewText7Objects1= [];
gdjs.Untitled_32sceneCode.GDNewText7Objects2= [];


gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDFireballObjects1Objects = Hashtable.newFrom({"Fireball": gdjs.Untitled_32sceneCode.GDFireballObjects1});
gdjs.Untitled_32sceneCode.asyncCallback15592636 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
gdjs.Untitled_32sceneCode.localVariables.length = 0;
}
gdjs.Untitled_32sceneCode.idToCallbackMap.set(15592636, gdjs.Untitled_32sceneCode.asyncCallback15592636);
gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.Untitled_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtsExt__CrazyGamesAdApi__DisplayCrazyGamesAd.func(runtimeScene, "rewarded", null), (runtimeScene) => (gdjs.Untitled_32sceneCode.asyncCallback15592636(runtimeScene, asyncObjectsList)), 15592636, asyncObjectsList);
}
}

}


};gdjs.Untitled_32sceneCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BlackDecoratedButton"), gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlueButton"), gdjs.Untitled_32sceneCode.GDBlueButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Cat_1"), gdjs.Untitled_32sceneCode.GDCat_95951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Chicken"), gdjs.Untitled_32sceneCode.GDChickenObjects1);
gdjs.copyArray(runtimeScene.getObjects("Dino_Vita"), gdjs.Untitled_32sceneCode.GDDino_9595VitaObjects1);
gdjs.copyArray(runtimeScene.getObjects("Fireball"), gdjs.Untitled_32sceneCode.GDFireballObjects1);
gdjs.copyArray(runtimeScene.getObjects("Gold_Coin"), gdjs.Untitled_32sceneCode.GDGold_9595CoinObjects1);
gdjs.copyArray(runtimeScene.getObjects("Large_Block_Rectangle"), gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595RectangleObjects1);
gdjs.copyArray(runtimeScene.getObjects("Large_Block_Rectangle2"), gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595Rectangle2Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Untitled_32sceneCode.GDNewTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewText2"), gdjs.Untitled_32sceneCode.GDNewText2Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewText6"), gdjs.Untitled_32sceneCode.GDNewText6Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewText7"), gdjs.Untitled_32sceneCode.GDNewText7Objects1);
gdjs.copyArray(runtimeScene.getObjects("RedButtonWithShadow"), gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1);
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.Untitled_32sceneCode.GDSkeletonObjects1);
gdjs.copyArray(runtimeScene.getObjects("TinyYellowButton"), gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tommy"), gdjs.Untitled_32sceneCode.GDTommyObjects1);
gdjs.copyArray(runtimeScene.getObjects("bee"), gdjs.Untitled_32sceneCode.GDbeeObjects1);
{gdjs.evtsExt__SwipeGesture__EnableSwipeDetection.func(runtimeScene, true, null);
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber((( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[0].getPointY("")));
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getBehavior("Tween").addObjectPositionXTween2("LaneMove", gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariables().getFromIndex(0).getAsNumber() * 100, "easeOutQuad", 0.18, false);
}
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "difficulty");
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDFireballObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDFireballObjects1[i].resetTimer("doublefire");
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595RectangleObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595RectangleObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewTextObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlueButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlueButtonObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewText2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewText2Objects1[i].resetTimer("score");
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGold_9595CoinObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGold_9595CoinObjects1[i].resetTimer("coin");
}
}
{gdjs.evtTools.storage.readNumberFromJSONFile("local", "game", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(0));
}
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 1);
}
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 2);
}
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 3);
}
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 4);
}
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 5);
}
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 6);
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "08 - The Creeper.aac", 1, true, 100, 1);
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbeeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbeeObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCat_95951Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCat_95951Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDTommyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDTommyObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDChickenObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDChickenObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSkeletonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSkeletonObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDino_9595VitaObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDino_9595VitaObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595Rectangle2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595Rectangle2Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewText7Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewText7Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewText6Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewText6Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].hide();
}
}
{gdjs.evtsExt__CrazyGamesAdApi__SetGameplayStarted.func(runtimeScene, null);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtsExt__SwipeGesture__HasSwipeJustEnded.func(runtimeScene, null);
if (isConditionTrue_2) {
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtsExt__SwipeGesture__SwipeDirection_4way.func(runtimeScene, "Left", null);
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) - runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() < -50);
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (Math.abs(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) - runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()) > Math.abs(gdjs.evtTools.input.getCursorY(runtimeScene, "", 0) - runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber()));
}
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariables().getFromIndex(0)).sub(1);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariables().getFromIndex(0)).setNumber(gdjs.evtTools.common.clamp(gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariables().getFromIndex(0).getAsNumber(), 1, 4));
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getBehavior("Tween").addObjectPositionXTween2("LaneMove", gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariables().getFromIndex(0).getAsNumber() * 100, "easeOutQuad", 0.18, false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtsExt__SwipeGesture__HasSwipeJustEnded.func(runtimeScene, null);
if (isConditionTrue_2) {
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtsExt__SwipeGesture__SwipeDirection_4way.func(runtimeScene, "Right", null);
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) - runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() > 50);
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (Math.abs(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) - runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()) > Math.abs(gdjs.evtTools.input.getCursorY(runtimeScene, "", 0) - runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber()));
}
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariables().getFromIndex(0)).add(1);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariables().getFromIndex(0)).setNumber(gdjs.evtTools.common.clamp(gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariables().getFromIndex(0).getAsNumber(), 2, 3));
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getBehavior("Tween").addObjectPositionXTween2("LaneMove", gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariables().getFromIndex(0).getAsNumber() * 130, "easeOutQuad", 0.18, false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtsExt__SwipeGesture__HasSwipeJustEnded.func(runtimeScene, null);
if (isConditionTrue_2) {
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtsExt__SwipeGesture__SwipeDirection_4way.func(runtimeScene, "Up", null);
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (gdjs.evtTools.input.getCursorY(runtimeScene, "", 0) - runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() < -50);
}
if (isConditionTrue_2) {
isConditionTrue_2 = false;
{isConditionTrue_2 = (Math.abs(gdjs.evtTools.input.getCursorY(runtimeScene, "", 0) - runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber()) > Math.abs(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) - runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber()));
}
}
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Up");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getY() == runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[k] = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDNewSpriteObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getBehavior("Tween").addObjectPositionYTween2("JumpUp", runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() - 300, "easeOutQuad", 0.25, false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getBehavior("Tween").hasFinished("JumpUp") ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[k] = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDNewSpriteObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getBehavior("Tween").addObjectPositionYTween2("JumpDown", runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber(), "easeOutQuad", 0.3, false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getBehavior("Tween").removeTween("JumpUp");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariables().getFromIndex(0)) < 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[k] = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDNewSpriteObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariables().getFromIndex(0)) > 6 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[k] = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDNewSpriteObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariables().getFromIndex(0)).setNumber(6);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.hasAnyTouchOrMouseStarted(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0));
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Fireball"), gdjs.Untitled_32sceneCode.GDFireballObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDFireballObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDFireballObjects1[i].getBehavior("Scale").setScale(gdjs.Untitled_32sceneCode.GDFireballObjects1[i].getBehavior("Scale").getScale() + (0.02 + (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() * 0.05)));
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Fireball"), gdjs.Untitled_32sceneCode.GDFireballObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDFireballObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDFireballObjects1[i].getBehavior("Scale").getScale() > 10 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDFireballObjects1[k] = gdjs.Untitled_32sceneCode.GDFireballObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDFireballObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDFireballObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDFireballObjects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDFireballObjects1[i].getVariables().getFromIndex(3)) == ((gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[0].getVariables()).getFromIndex(0).getAsNumber() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDFireballObjects1[k] = gdjs.Untitled_32sceneCode.GDFireballObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDFireballObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDFireballObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDNewSpriteObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariables().getFromIndex(1)).setNumber(1);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].hide();
}
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Death.aac", 3, false, 100, 1);
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDFireballObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDFireballObjects1[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Fireball"), gdjs.Untitled_32sceneCode.GDFireballObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDFireballObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDFireballObjects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDFireballObjects1[i].getVariables().getFromIndex(3)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDFireballObjects1[k] = gdjs.Untitled_32sceneCode.GDFireballObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDFireballObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDFireballObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDFireballObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDFireballObjects1[i].setX(5);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Fireball"), gdjs.Untitled_32sceneCode.GDFireballObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDFireballObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDFireballObjects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDFireballObjects1[i].getVariables().getFromIndex(3)) == 2 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDFireballObjects1[k] = gdjs.Untitled_32sceneCode.GDFireballObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDFireballObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDFireballObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDFireballObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDFireballObjects1[i].setX(225);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Fireball"), gdjs.Untitled_32sceneCode.GDFireballObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDFireballObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDFireballObjects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDFireballObjects1[i].getVariables().getFromIndex(3)) == 3 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDFireballObjects1[k] = gdjs.Untitled_32sceneCode.GDFireballObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDFireballObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDFireballObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDFireballObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDFireballObjects1[i].setX(400);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Fireball"), gdjs.Untitled_32sceneCode.GDFireballObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDFireballObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDFireballObjects1[i].getBehavior("Scale").getScale() > 11 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDFireballObjects1[k] = gdjs.Untitled_32sceneCode.GDFireballObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDFireballObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDFireballObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDFireballObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDFireballObjects1[i].getBehavior("Scale").setScale(0.02);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDFireballObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDFireballObjects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDFireballObjects1[i].getVariables().getFromIndex(3)).setNumber(gdjs.randomInRange(1, 3));
}
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Explosion 5.aac", 4, false, 100, 1);
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDFireballObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDFireballObjects1[i].setY(1025);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "difficulty") > 15;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "difficulty");
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Fireball"), gdjs.Untitled_32sceneCode.GDFireballObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDFireballObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDFireballObjects1[i].getTimerElapsedTimeInSecondsOrNaN("doublefire") >= 30 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDFireballObjects1[k] = gdjs.Untitled_32sceneCode.GDFireballObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDFireballObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDFireballObjects1 */
{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDFireballObjects1Objects, 150, 950, "");
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDFireballObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDFireballObjects1[i].removeTimer("doublefire");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[k] = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15589428);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Large_Block_Rectangle2"), gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595Rectangle2Objects1);
gdjs.copyArray(runtimeScene.getObjects("RedButtonWithShadow"), gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1);
gdjs.copyArray(runtimeScene.getObjects("TinyYellowButton"), gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595Rectangle2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595Rectangle2Objects1[i].hide(false);
}
}
{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 1, 0, 0, null);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("RedButtonWithShadow"), gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1[k] = gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1[k] = gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15591332);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fireball"), gdjs.Untitled_32sceneCode.GDFireballObjects1);
gdjs.copyArray(runtimeScene.getObjects("Large_Block_Rectangle2"), gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595Rectangle2Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);
/* Reuse gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1 */
gdjs.copyArray(runtimeScene.getObjects("TinyYellowButton"), gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].returnVariable(gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariables().getFromIndex(1)).setNumber(0);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1[i].hide();
}
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Click_03.aac", 2, false, 100, 1);
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDFireballObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDFireballObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595Rectangle2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595Rectangle2Objects1[i].hide();
}
}

{ //Subevents
gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("TinyYellowButton"), gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1[k] = gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1[k] = gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BlackDecoratedButton"), gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("BlueButton"), gdjs.Untitled_32sceneCode.GDBlueButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Large_Block_Rectangle"), gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595RectangleObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.Untitled_32sceneCode.GDNewTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewText6"), gdjs.Untitled_32sceneCode.GDNewText6Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewText7"), gdjs.Untitled_32sceneCode.GDNewText7Objects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595RectangleObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595RectangleObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewTextObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlueButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlueButtonObjects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects1[i].hide(false);
}
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Click_03.aac", 2, false, 100, 1);
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewText6Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewText6Objects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewText7Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewText7Objects1[i].hide(false);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewText7Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewText7Objects1[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(4).getAsString());
}
}
{runtimeScene.getGame().getVariables().getFromIndex(0).add(runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber());
}
{gdjs.evtTools.storage.writeNumberInJSONFile("local", "game", runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber());
}
{gdjs.evtTools.leaderboards.savePlayerScore(runtimeScene, "cfaa8b1f-be50-4f18-a0f8-8a6c22a209ea", runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber(), "");
}
{gdjs.evtsExt__CrazyGamesAdApi__SetGameplayStopped.func(runtimeScene, null);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlackDecoratedButton"), gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects1[k] = gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects1[k] = gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects1.length = k;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Untitled scene", false);
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Click_03.aac", 2, false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("BlueButton"), gdjs.Untitled_32sceneCode.GDBlueButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBlueButtonObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBlueButtonObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBlueButtonObjects1[k] = gdjs.Untitled_32sceneCode.GDBlueButtonObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBlueButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDBlueButtonObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDBlueButtonObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDBlueButtonObjects1[k] = gdjs.Untitled_32sceneCode.GDBlueButtonObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDBlueButtonObjects1.length = k;
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main menu", false);
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Click_03.aac", 2, false, 100, 1);
}
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewText2"), gdjs.Untitled_32sceneCode.GDNewText2Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDNewText2Objects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDNewText2Objects1[i].getTimerElapsedTimeInSecondsOrNaN("score") > 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDNewText2Objects1[k] = gdjs.Untitled_32sceneCode.GDNewText2Objects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDNewText2Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariables().getFromIndex(1)) == 0 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[k] = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDNewText2Objects1 */
{runtimeScene.getScene().getVariables().getFromIndex(4).add(1);
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewText2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewText2Objects1[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(4).getAsString());
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewText2Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewText2Objects1[i].resetTimer("score");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[k] = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber() > runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber());
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber());
}
{gdjs.evtTools.storage.writeNumberInJSONFile("local", "bestscore", runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber());
}
}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.storage.readNumberFromJSONFile("local", "bestscore", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(1));
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewText3"), gdjs.Untitled_32sceneCode.GDNewText3Objects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewText3Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewText3Objects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(1).getAsString());
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewText4"), gdjs.Untitled_32sceneCode.GDNewText4Objects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewText4Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewText4Objects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(0).getAsString());
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Cat_1"), gdjs.Untitled_32sceneCode.GDCat_95951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Chicken"), gdjs.Untitled_32sceneCode.GDChickenObjects1);
gdjs.copyArray(runtimeScene.getObjects("Dino_Vita"), gdjs.Untitled_32sceneCode.GDDino_9595VitaObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.Untitled_32sceneCode.GDSkeletonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tommy"), gdjs.Untitled_32sceneCode.GDTommyObjects1);
gdjs.copyArray(runtimeScene.getObjects("bee"), gdjs.Untitled_32sceneCode.GDbeeObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbeeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbeeObjects1[i].setX((( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[0].getPointX("")));
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCat_95951Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCat_95951Objects1[i].setX((( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[0].getPointX("")) - 120);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDTommyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDTommyObjects1[i].setX((( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[0].getPointX("")));
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDChickenObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDChickenObjects1[i].setX((( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[0].getPointX("")));
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSkeletonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSkeletonObjects1[i].setX((( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[0].getPointX("")));
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDino_9595VitaObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDino_9595VitaObjects1[i].setX((( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[0].getPointX("")));
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbeeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbeeObjects1[i].setY((( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[0].getPointY("")) - 20);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCat_95951Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCat_95951Objects1[i].setY((( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[0].getPointY("")) - 157);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDTommyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDTommyObjects1[i].setY((( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[0].getPointY("")) - 20);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDChickenObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDChickenObjects1[i].setY((( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[0].getPointY("")));
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSkeletonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSkeletonObjects1[i].setY((( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[0].getPointY("")) - 20);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDino_9595VitaObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDino_9595VitaObjects1[i].setY((( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[0].getPointY("")) - 20);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsString() == "Standard");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Tommy"), gdjs.Untitled_32sceneCode.GDTommyObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDTommyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDTommyObjects1[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsString() == "DarkBlue");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Dino_Vita"), gdjs.Untitled_32sceneCode.GDDino_9595VitaObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDino_9595VitaObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDino_9595VitaObjects1[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsString() == "Pink");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.Untitled_32sceneCode.GDSkeletonObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSkeletonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSkeletonObjects1[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsString() == "Gold");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("bee"), gdjs.Untitled_32sceneCode.GDbeeObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbeeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbeeObjects1[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsString() == "Lightblue");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Chicken"), gdjs.Untitled_32sceneCode.GDChickenObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDChickenObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDChickenObjects1[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsString() == "Red");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cat_1"), gdjs.Untitled_32sceneCode.GDCat_95951Objects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCat_95951Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCat_95951Objects1[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsString() == "");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Tommy"), gdjs.Untitled_32sceneCode.GDTommyObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDTommyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDTommyObjects1[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariableNumber(gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].getVariables().getFromIndex(1)) == 1 ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[k] = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Cat_1"), gdjs.Untitled_32sceneCode.GDCat_95951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Chicken"), gdjs.Untitled_32sceneCode.GDChickenObjects1);
gdjs.copyArray(runtimeScene.getObjects("Dino_Vita"), gdjs.Untitled_32sceneCode.GDDino_9595VitaObjects1);
gdjs.copyArray(runtimeScene.getObjects("Skeleton"), gdjs.Untitled_32sceneCode.GDSkeletonObjects1);
gdjs.copyArray(runtimeScene.getObjects("Tommy"), gdjs.Untitled_32sceneCode.GDTommyObjects1);
gdjs.copyArray(runtimeScene.getObjects("bee"), gdjs.Untitled_32sceneCode.GDbeeObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDTommyObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDTommyObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDbeeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDbeeObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDCat_95951Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDCat_95951Objects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDChickenObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDChickenObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDSkeletonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDSkeletonObjects1[i].hide();
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDino_9595VitaObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDino_9595VitaObjects1[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() > 9999);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(9999);
}
{gdjs.evtTools.storage.writeNumberInJSONFile("local", "game", runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber());
}
}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCave_9595BackgroundObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCave_9595BackgroundObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStoneObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStoneObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDFireballObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDFireballObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCannonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCannonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595RectangleObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595RectangleObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBlueButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBlueButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewText2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewText2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewText3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewText3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDGold_9595CoinObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGold_9595CoinObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewText4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewText4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDDino_9595VitaObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDino_9595VitaObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSkeletonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSkeletonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDChickenObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDChickenObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTommyObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTommyObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCat_95951Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDCat_95951Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDbeeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbeeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595Rectangle2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595Rectangle2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDScore2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDScore2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDScore3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDScore3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewText5Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewText5Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewText6Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewText6Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewText7Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewText7Objects2.length = 0;

gdjs.Untitled_32sceneCode.eventsList1(runtimeScene);
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCave_9595BackgroundObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCave_9595BackgroundObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDStoneObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDStoneObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDFireballObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDFireballObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCannonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDCannonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595RectangleObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595RectangleObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDRedButtonWithShadowObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTinyYellowButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewTextObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBlueButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBlueButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBlackDecoratedButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewText2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewText2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewText3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewText3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDGold_9595CoinObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGold_9595CoinObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewText4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewText4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDDino_9595VitaObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDino_9595VitaObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSkeletonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSkeletonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDChickenObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDChickenObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTommyObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTommyObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDCat_95951Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDCat_95951Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDbeeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDbeeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595Rectangle2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDLarge_9595Block_9595Rectangle2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDScore2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDScore2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDScore3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDScore3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewText5Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewText5Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewText6Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewText6Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewText7Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewText7Objects2.length = 0;


return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
