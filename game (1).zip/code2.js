gdjs.ShopCode = {};
gdjs.ShopCode.localVariables = [];
gdjs.ShopCode.idToCallbackMap = new Map();
gdjs.ShopCode.GDNewTextObjects1= [];
gdjs.ShopCode.GDNewTextObjects2= [];
gdjs.ShopCode.GDRedButtonWithShadowObjects1= [];
gdjs.ShopCode.GDRedButtonWithShadowObjects2= [];
gdjs.ShopCode.GDgreenObjects1= [];
gdjs.ShopCode.GDgreenObjects2= [];
gdjs.ShopCode.GDgreen7Objects1= [];
gdjs.ShopCode.GDgreen7Objects2= [];
gdjs.ShopCode.GDgreen3Objects1= [];
gdjs.ShopCode.GDgreen3Objects2= [];
gdjs.ShopCode.GDgreen4Objects1= [];
gdjs.ShopCode.GDgreen4Objects2= [];
gdjs.ShopCode.GDgreen5Objects1= [];
gdjs.ShopCode.GDgreen5Objects2= [];
gdjs.ShopCode.GDgreen6Objects1= [];
gdjs.ShopCode.GDgreen6Objects2= [];
gdjs.ShopCode.GDNewText2Objects1= [];
gdjs.ShopCode.GDNewText2Objects2= [];
gdjs.ShopCode.GDNewText3Objects1= [];
gdjs.ShopCode.GDNewText3Objects2= [];
gdjs.ShopCode.GDNewText4Objects1= [];
gdjs.ShopCode.GDNewText4Objects2= [];
gdjs.ShopCode.GDNewText5Objects1= [];
gdjs.ShopCode.GDNewText5Objects2= [];
gdjs.ShopCode.GDNewText6Objects1= [];
gdjs.ShopCode.GDNewText6Objects2= [];
gdjs.ShopCode.GDNewText7Objects1= [];
gdjs.ShopCode.GDNewText7Objects2= [];
gdjs.ShopCode.GDNewText8Objects1= [];
gdjs.ShopCode.GDNewText8Objects2= [];
gdjs.ShopCode.GDNewText9Objects1= [];
gdjs.ShopCode.GDNewText9Objects2= [];
gdjs.ShopCode.GDNewText10Objects1= [];
gdjs.ShopCode.GDNewText10Objects2= [];
gdjs.ShopCode.GDNewText11Objects1= [];
gdjs.ShopCode.GDNewText11Objects2= [];
gdjs.ShopCode.GDOwnedObjects1= [];
gdjs.ShopCode.GDOwnedObjects2= [];
gdjs.ShopCode.GDWood_9595BackgroundObjects1= [];
gdjs.ShopCode.GDWood_9595BackgroundObjects2= [];
gdjs.ShopCode.GDcurrent_9595skinObjects1= [];
gdjs.ShopCode.GDcurrent_9595skinObjects2= [];
gdjs.ShopCode.GDNewText12Objects1= [];
gdjs.ShopCode.GDNewText12Objects2= [];


gdjs.ShopCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 1);
}
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 2);
}
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 3);
}
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 4);
}
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 5);
}
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 6);
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Brandenburg Concerto III, Allegro I.aac", 5, true, 100, 1);
}
{gdjs.evtTools.storage.readNumberFromJSONFile("darkblue", "skindb", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(3));
}
{gdjs.evtTools.storage.readNumberFromJSONFile("darkblue", "skins", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(2));
}
{gdjs.evtTools.storage.readNumberFromJSONFile("darkblue", "skinr", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(4));
}
{gdjs.evtTools.storage.readNumberFromJSONFile("darkblue", "sking", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(7));
}
{gdjs.evtTools.storage.readNumberFromJSONFile("darkblue", "skinlb", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(6));
}
{gdjs.evtTools.storage.readNumberFromJSONFile("darkblue", "skinp", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(5));
}
{gdjs.evtTools.storage.readNumberFromJSONFile("darkblue", "skinsave", runtimeScene, runtimeScene.getGame().getVariables().getFromIndex(5));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("RedButtonWithShadow"), gdjs.ShopCode.GDRedButtonWithShadowObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDRedButtonWithShadowObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDRedButtonWithShadowObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDRedButtonWithShadowObjects1[k] = gdjs.ShopCode.GDRedButtonWithShadowObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDRedButtonWithShadowObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Main menu", false);
}
{gdjs.evtTools.sound.stopSoundOnChannel(runtimeScene, 5);
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Click_03.aac", 2, false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("green7"), gdjs.ShopCode.GDgreen7Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDgreen7Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDgreen7Objects1[i].IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDgreen7Objects1[k] = gdjs.ShopCode.GDgreen7Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDgreen7Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() >= 100);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(100);
}
{runtimeScene.getGame().getVariables().getFromIndex(3).setNumber(1);
}
{gdjs.evtTools.storage.writeNumberInJSONFile("local", "game", runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber());
}
{gdjs.evtTools.storage.writeNumberInJSONFile("darkblue", "skindb", runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber());
}
{runtimeScene.getGame().getVariables().getFromIndex(8).setString("Darkblue");
}
{gdjs.evtTools.storage.writeNumberInJSONFile("selectedskin", "skinsave", runtimeScene.getGame().getVariables().getFromIndex(8).getAsNumber());
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Click_03.aac", 2, false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("green7"), gdjs.ShopCode.GDgreen7Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDgreen7Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDgreen7Objects1[i].IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDgreen7Objects1[k] = gdjs.ShopCode.GDgreen7Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDgreen7Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(3).getAsNumber() == 1);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(8).setString("Darkblue");
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Click_03.aac", 2, false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("green"), gdjs.ShopCode.GDgreenObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDgreenObjects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDgreenObjects1[i].IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDgreenObjects1[k] = gdjs.ShopCode.GDgreenObjects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDgreenObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber() == 1);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() >= 0);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(0);
}
{runtimeScene.getGame().getVariables().getFromIndex(2).setNumber(1);
}
{gdjs.evtTools.storage.writeNumberInJSONFile("local", "game", runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber());
}
{gdjs.evtTools.storage.writeNumberInJSONFile("darkblue", "skins", runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber());
}
{runtimeScene.getGame().getVariables().getFromIndex(8).setString("Standard");
}
{gdjs.evtTools.storage.writeNumberInJSONFile("selectedskin", "skinsave", runtimeScene.getGame().getVariables().getFromIndex(8).getAsNumber());
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Click_03.aac", 2, false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("green3"), gdjs.ShopCode.GDgreen3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDgreen3Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDgreen3Objects1[i].IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDgreen3Objects1[k] = gdjs.ShopCode.GDgreen3Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDgreen3Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() == 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() >= 200);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(200);
}
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(1);
}
{gdjs.evtTools.storage.writeNumberInJSONFile("local", "game", runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber());
}
{gdjs.evtTools.storage.writeNumberInJSONFile("darkblue", "skinr", runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber());
}
{runtimeScene.getGame().getVariables().getFromIndex(8).setString("Red");
}
{gdjs.evtTools.storage.writeNumberInJSONFile("selectedskin", "skinsave", runtimeScene.getGame().getVariables().getFromIndex(8).getAsNumber());
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Click_03.aac", 2, false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("green7"), gdjs.ShopCode.GDgreen7Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDgreen7Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDgreen7Objects1[i].IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDgreen7Objects1[k] = gdjs.ShopCode.GDgreen7Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDgreen7Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(5).getAsNumber() == 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() >= 500);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(500);
}
{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(1);
}
{gdjs.evtTools.storage.writeNumberInJSONFile("local", "game", runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber());
}
{gdjs.evtTools.storage.writeNumberInJSONFile("darkblue", "skinp", runtimeScene.getGame().getVariables().getFromIndex(5).getAsNumber());
}
{runtimeScene.getGame().getVariables().getFromIndex(8).setString("Pink");
}
{gdjs.evtTools.storage.writeNumberInJSONFile("selectedskin", "skinsave", runtimeScene.getGame().getVariables().getFromIndex(8).getAsNumber());
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Click_03.aac", 2, false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("green5"), gdjs.ShopCode.GDgreen5Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDgreen5Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDgreen5Objects1[i].IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDgreen5Objects1[k] = gdjs.ShopCode.GDgreen5Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDgreen5Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber() == 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() >= 1000);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(1000);
}
{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(1);
}
{gdjs.evtTools.storage.writeNumberInJSONFile("local", "game", runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber());
}
{gdjs.evtTools.storage.writeNumberInJSONFile("darkblue", "skinlb", runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber());
}
{runtimeScene.getGame().getVariables().getFromIndex(8).setString("Lightblue");
}
{gdjs.evtTools.storage.writeNumberInJSONFile("selectedskin", "skinsave", runtimeScene.getGame().getVariables().getFromIndex(8).getAsNumber());
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Click_03.aac", 2, false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("green6"), gdjs.ShopCode.GDgreen6Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDgreen6Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDgreen6Objects1[i].IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDgreen6Objects1[k] = gdjs.ShopCode.GDgreen6Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDgreen6Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(7).getAsNumber() == 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() >= 5000);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).sub(5000);
}
{runtimeScene.getGame().getVariables().getFromIndex(7).setNumber(1);
}
{gdjs.evtTools.storage.writeNumberInJSONFile("local", "game", runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber());
}
{gdjs.evtTools.storage.writeNumberInJSONFile("darkblue", "sking", runtimeScene.getGame().getVariables().getFromIndex(7).getAsNumber());
}
{runtimeScene.getGame().getVariables().getFromIndex(8).setString("Gold");
}
{gdjs.evtTools.storage.writeNumberInJSONFile("selectedskin", "sking", runtimeScene.getGame().getVariables().getFromIndex(8).getAsNumber());
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Click_03.aac", 2, false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("green3"), gdjs.ShopCode.GDgreen3Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDgreen3Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDgreen3Objects1[i].IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDgreen3Objects1[k] = gdjs.ShopCode.GDgreen3Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDgreen3Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() == 1);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(8).setString("Red");
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Click_03.aac", 2, false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("green7"), gdjs.ShopCode.GDgreen7Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDgreen7Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDgreen7Objects1[i].IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDgreen7Objects1[k] = gdjs.ShopCode.GDgreen7Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDgreen7Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(5).getAsNumber() == 1);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(8).setString("Pink");
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Click_03.aac", 2, false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("green4"), gdjs.ShopCode.GDgreen4Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDgreen4Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDgreen4Objects1[i].IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDgreen4Objects1[k] = gdjs.ShopCode.GDgreen4Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDgreen4Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber() == 1);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(8).setString("Standard");
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Click_03.aac", 2, false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("green5"), gdjs.ShopCode.GDgreen5Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDgreen5Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDgreen5Objects1[i].IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDgreen5Objects1[k] = gdjs.ShopCode.GDgreen5Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDgreen5Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(6).getAsNumber() == 1);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(8).setString("Lightblue");
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Click_03.aac", 2, false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("green6"), gdjs.ShopCode.GDgreen6Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.ShopCode.GDgreen6Objects1.length;i<l;++i) {
    if ( gdjs.ShopCode.GDgreen6Objects1[i].IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.ShopCode.GDgreen6Objects1[k] = gdjs.ShopCode.GDgreen6Objects1[i];
        ++k;
    }
}
gdjs.ShopCode.GDgreen6Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(7).getAsNumber() == 1);
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(8).setString("Gold");
}
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Click_03.aac", 2, false, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewText10"), gdjs.ShopCode.GDNewText10Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewText11"), gdjs.ShopCode.GDNewText11Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewText3"), gdjs.ShopCode.GDNewText3Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewText8"), gdjs.ShopCode.GDNewText8Objects1);
gdjs.copyArray(runtimeScene.getObjects("NewText9"), gdjs.ShopCode.GDNewText9Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDNewText3Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDNewText3Objects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(2).getAsString());
}
}
{for(var i = 0, len = gdjs.ShopCode.GDNewText8Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDNewText8Objects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(4).getAsString());
}
}
{for(var i = 0, len = gdjs.ShopCode.GDNewText9Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDNewText9Objects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(5).getAsString());
}
}
{for(var i = 0, len = gdjs.ShopCode.GDNewText10Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDNewText10Objects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(7).getAsString());
}
}
{for(var i = 0, len = gdjs.ShopCode.GDNewText11Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDNewText11Objects1[i].getBehavior("Text").setText(runtimeScene.getGame().getVariables().getFromIndex(6).getAsString());
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() > 9999);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(9999);
}
{gdjs.evtTools.storage.writeNumberInJSONFile("local", "game", runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber());
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsString() == "Standard");
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setString("Standard");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsString() == "Pink");
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setString("Skeleton");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsString() == "Gold");
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setString("Bee");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsString() == "Lightblue");
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setString("Chicken");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsString() == "");
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setString("Standard");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(8).getAsString() == "Red");
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setString("Cat");
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("NewText12"), gdjs.ShopCode.GDNewText12Objects1);
{for(var i = 0, len = gdjs.ShopCode.GDNewText12Objects1.length ;i < len;++i) {
    gdjs.ShopCode.GDNewText12Objects1[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(0).getAsString());
}
}
}

}


};

gdjs.ShopCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.ShopCode.GDNewTextObjects1.length = 0;
gdjs.ShopCode.GDNewTextObjects2.length = 0;
gdjs.ShopCode.GDRedButtonWithShadowObjects1.length = 0;
gdjs.ShopCode.GDRedButtonWithShadowObjects2.length = 0;
gdjs.ShopCode.GDgreenObjects1.length = 0;
gdjs.ShopCode.GDgreenObjects2.length = 0;
gdjs.ShopCode.GDgreen7Objects1.length = 0;
gdjs.ShopCode.GDgreen7Objects2.length = 0;
gdjs.ShopCode.GDgreen3Objects1.length = 0;
gdjs.ShopCode.GDgreen3Objects2.length = 0;
gdjs.ShopCode.GDgreen4Objects1.length = 0;
gdjs.ShopCode.GDgreen4Objects2.length = 0;
gdjs.ShopCode.GDgreen5Objects1.length = 0;
gdjs.ShopCode.GDgreen5Objects2.length = 0;
gdjs.ShopCode.GDgreen6Objects1.length = 0;
gdjs.ShopCode.GDgreen6Objects2.length = 0;
gdjs.ShopCode.GDNewText2Objects1.length = 0;
gdjs.ShopCode.GDNewText2Objects2.length = 0;
gdjs.ShopCode.GDNewText3Objects1.length = 0;
gdjs.ShopCode.GDNewText3Objects2.length = 0;
gdjs.ShopCode.GDNewText4Objects1.length = 0;
gdjs.ShopCode.GDNewText4Objects2.length = 0;
gdjs.ShopCode.GDNewText5Objects1.length = 0;
gdjs.ShopCode.GDNewText5Objects2.length = 0;
gdjs.ShopCode.GDNewText6Objects1.length = 0;
gdjs.ShopCode.GDNewText6Objects2.length = 0;
gdjs.ShopCode.GDNewText7Objects1.length = 0;
gdjs.ShopCode.GDNewText7Objects2.length = 0;
gdjs.ShopCode.GDNewText8Objects1.length = 0;
gdjs.ShopCode.GDNewText8Objects2.length = 0;
gdjs.ShopCode.GDNewText9Objects1.length = 0;
gdjs.ShopCode.GDNewText9Objects2.length = 0;
gdjs.ShopCode.GDNewText10Objects1.length = 0;
gdjs.ShopCode.GDNewText10Objects2.length = 0;
gdjs.ShopCode.GDNewText11Objects1.length = 0;
gdjs.ShopCode.GDNewText11Objects2.length = 0;
gdjs.ShopCode.GDOwnedObjects1.length = 0;
gdjs.ShopCode.GDOwnedObjects2.length = 0;
gdjs.ShopCode.GDWood_9595BackgroundObjects1.length = 0;
gdjs.ShopCode.GDWood_9595BackgroundObjects2.length = 0;
gdjs.ShopCode.GDcurrent_9595skinObjects1.length = 0;
gdjs.ShopCode.GDcurrent_9595skinObjects2.length = 0;
gdjs.ShopCode.GDNewText12Objects1.length = 0;
gdjs.ShopCode.GDNewText12Objects2.length = 0;

gdjs.ShopCode.eventsList0(runtimeScene);
gdjs.ShopCode.GDNewTextObjects1.length = 0;
gdjs.ShopCode.GDNewTextObjects2.length = 0;
gdjs.ShopCode.GDRedButtonWithShadowObjects1.length = 0;
gdjs.ShopCode.GDRedButtonWithShadowObjects2.length = 0;
gdjs.ShopCode.GDgreenObjects1.length = 0;
gdjs.ShopCode.GDgreenObjects2.length = 0;
gdjs.ShopCode.GDgreen7Objects1.length = 0;
gdjs.ShopCode.GDgreen7Objects2.length = 0;
gdjs.ShopCode.GDgreen3Objects1.length = 0;
gdjs.ShopCode.GDgreen3Objects2.length = 0;
gdjs.ShopCode.GDgreen4Objects1.length = 0;
gdjs.ShopCode.GDgreen4Objects2.length = 0;
gdjs.ShopCode.GDgreen5Objects1.length = 0;
gdjs.ShopCode.GDgreen5Objects2.length = 0;
gdjs.ShopCode.GDgreen6Objects1.length = 0;
gdjs.ShopCode.GDgreen6Objects2.length = 0;
gdjs.ShopCode.GDNewText2Objects1.length = 0;
gdjs.ShopCode.GDNewText2Objects2.length = 0;
gdjs.ShopCode.GDNewText3Objects1.length = 0;
gdjs.ShopCode.GDNewText3Objects2.length = 0;
gdjs.ShopCode.GDNewText4Objects1.length = 0;
gdjs.ShopCode.GDNewText4Objects2.length = 0;
gdjs.ShopCode.GDNewText5Objects1.length = 0;
gdjs.ShopCode.GDNewText5Objects2.length = 0;
gdjs.ShopCode.GDNewText6Objects1.length = 0;
gdjs.ShopCode.GDNewText6Objects2.length = 0;
gdjs.ShopCode.GDNewText7Objects1.length = 0;
gdjs.ShopCode.GDNewText7Objects2.length = 0;
gdjs.ShopCode.GDNewText8Objects1.length = 0;
gdjs.ShopCode.GDNewText8Objects2.length = 0;
gdjs.ShopCode.GDNewText9Objects1.length = 0;
gdjs.ShopCode.GDNewText9Objects2.length = 0;
gdjs.ShopCode.GDNewText10Objects1.length = 0;
gdjs.ShopCode.GDNewText10Objects2.length = 0;
gdjs.ShopCode.GDNewText11Objects1.length = 0;
gdjs.ShopCode.GDNewText11Objects2.length = 0;
gdjs.ShopCode.GDOwnedObjects1.length = 0;
gdjs.ShopCode.GDOwnedObjects2.length = 0;
gdjs.ShopCode.GDWood_9595BackgroundObjects1.length = 0;
gdjs.ShopCode.GDWood_9595BackgroundObjects2.length = 0;
gdjs.ShopCode.GDcurrent_9595skinObjects1.length = 0;
gdjs.ShopCode.GDcurrent_9595skinObjects2.length = 0;
gdjs.ShopCode.GDNewText12Objects1.length = 0;
gdjs.ShopCode.GDNewText12Objects2.length = 0;


return;

}

gdjs['ShopCode'] = gdjs.ShopCode;
